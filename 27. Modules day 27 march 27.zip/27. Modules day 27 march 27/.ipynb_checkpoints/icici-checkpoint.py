bname="ICICI Bgl"
state="Karnataka"
# define a function to calculate intrest
def add():
    p=float(input("enter the Principal Amount"))
    t=float(input("enter the time"))
    r=float(input("enter the rate of intrest: "))
    I =p*t*r/100
    total_amount=I+p
    return total_amount

# call(import) this in the importing_modules program and use there           
