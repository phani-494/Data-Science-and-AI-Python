PI=3.14 # both are treated as global variables in python 
E=2.71
